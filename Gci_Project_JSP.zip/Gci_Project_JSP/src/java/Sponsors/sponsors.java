
package Sponsors;
import java.awt.*;
import java.applet.*;

public class sponsors extends Applet
{
private AudioClip mysound;
private Image img, img1, img2, img3, img4,img5, img6, img7, img8, img9, img10, img11,img12, img13, img14, img15;
Font f;
private float speedX=3;
private float speedY=2;
private final int UPDATE_RATE=30;
private final int Box_Width=1000;
private final int Box_Height=600;

Thread tt=new Thread();
public void run(){

    while(true){  
    }

}

@Override
public void init()
{
    setSize(1000,600);
    setBackground(Color.BLUE);
    mysound=getAudioClip(getCodeBase(),"img/Sports Stadium Crowd Cheering Sound Effect.mp3");
    mysound.play();
    f=new Font("Elephant", Font.TRUETYPE_FONT, 15);
     img = getImage(getCodeBase(), "img/cola.png");
     img1 = getImage(getCodeBase(), "img/ebet.png");
     img2 = getImage(getCodeBase(), "img/micro.png");
     img3 = getImage(getCodeBase(), "img/mtn.png");
     
     img4 = getImage(getCodeBase(), "img/net.png");
     img5 = getImage(getCodeBase(), "img/mula.png");
     img6 = getImage(getCodeBase(), "img/gali.jpg");
     img7 = getImage(getCodeBase(), "img/addi.jpg");
     
     img8 = getImage(getCodeBase(), "img/oracle.jpg");
     img9 = getImage(getCodeBase(), "img/nike.jpg");
     img10 = getImage(getCodeBase(), "img/swazi.png");
     img11 = getImage(getCodeBase(), "img/swazib.jpg");
     
     img12 = getImage(getCodeBase(), "img/hilton.png");
     img13 = getImage(getCodeBase(), "img/spar.png");
     img14 = getImage(getCodeBase(), "img/standard.png");
     img15 = getImage(getCodeBase(), "img/swazib.jpg");
     

}

public void paint(Graphics g)
{
g.setColor(Color.black);
g.setFont(f);
g.drawString("OUR SPONSORS SECTION", 400, 20);

g.drawImage(img,180,60, getWidth()-900, getHeight()-500,this);
g.drawImage(img1,180,180, getWidth()-900, getHeight()-500,this);
g.drawImage(img2,180,300, getWidth()-900, getHeight()-500,this);
g.drawImage(img3,180,420, getWidth()-900, getHeight()-500,this);

g.drawImage(img4,350,60, getWidth()-900, getHeight()-500,this);
g.drawImage(img5,350,180, getWidth()-900, getHeight()-500,this);
g.drawImage(img6,350,300, getWidth()-900, getHeight()-500,this);
g.drawImage(img7,350,420, getWidth()-900, getHeight()-500,this);

g.drawImage(img8,520,60, getWidth()-900, getHeight()-500,this);
g.drawImage(img9,520,180, getWidth()-900, getHeight()-500,this);
g.drawImage(img10,520,300, getWidth()-900, getHeight()-500,this);
g.drawImage(img11,520,420, getWidth()-900, getHeight()-500,this);

g.drawImage(img12,690,60, getWidth()-900, getHeight()-500,this);
g.drawImage(img13,690,180, getWidth()-900, getHeight()-500,this);
g.drawImage(img14,690,300, getWidth()-900, getHeight()-500,this);
g.drawImage(img15,690,420, getWidth()-900, getHeight()-500,this);
}


}

