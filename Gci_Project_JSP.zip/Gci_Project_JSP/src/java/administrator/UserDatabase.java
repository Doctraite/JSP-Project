package administrator;

import java.sql.*;

public class UserDatabase {
    Connection con ;

    public UserDatabase(Connection con) {
        this.con = con;
    }
    
    //user login
    public addUsers login(String email, String pass){
        addUsers usr=null;
        try{
            String query ="select * from admin where email=? and password=?";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, email);
            pst.setString(2, pass);
           // pst.setString(3, type);
            
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                usr = new addUsers();
                usr.setId(rs.getInt("id"));
                usr.setName(rs.getString("name"));
                usr.setEmail(rs.getString("email"));
                usr.setPassword(rs.getString("password"));
                //usr.setType(rs.getString("type"));
                
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return usr;
    }

    
    //for register user 
    public boolean saveUser(addUsers user){
        boolean set = false;
        try{
            //Insert register data to database
            String query = "insert into admin(name,email,password) values(?,?,?)";
           
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, user.getName());
           pt.setString(2, user.getEmail());
           pt.setString(3, user.getPassword());
           //pt.setString(4, user.getType());
           
           pt.executeUpdate();
           set = true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
}